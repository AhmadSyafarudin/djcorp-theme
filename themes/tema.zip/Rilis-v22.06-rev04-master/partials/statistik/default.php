<?php if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<script type="text/javascript">
	let chart;
	const rawData = Object.values(<?= json_encode($stat) ?>);
	const type = '<?= $tipe == 1 ? 'column' : 'pie' ?>';
	const legend = Boolean(!<?= ($tipe) ?>);
	let categories = [];
	let data = [];
	let i = 1;
	let status_tampilkan = true;
	for (const stat of rawData) {
		if (stat.nama !== 'TOTAL' && stat.nama !== 'JUMLAH' && stat.nama != 'PENERIMA') {
			let filteredData = [stat.nama, parseInt(stat.jumlah)];
			categories.push(i);
			data.push(filteredData);
			i++;
		}
	}

	function tampilkan_nol(tampilkan = false) {
		if (tampilkan) {
			$(".nol").parent().show();
		} else {
			$(".nol").parent().hide();
		}
	}

	function toggle_tampilkan() {
		$('#showData').click();
		tampilkan_nol(status_tampilkan);
		status_tampilkan = !status_tampilkan;
		if (status_tampilkan) $('#tampilkan').text('Tampilkan Nol');
		else $('#tampilkan').text('Sembunyikan Nol');
	}

	function switchType(){
		var chartType = chart_penduduk.series[0].type;
		chart_penduduk.series[0].update({
			type: (chartType === 'pie') ? 'column' : 'pie'
		});
	}

	$(document).ready(function () {
		tampilkan_nol(false);
		if (<?=$this->setting->statistik_chart_3d?>) {
			chart_penduduk = new Highcharts.Chart({
				chart: {
					renderTo: 'container',
					options3d: {
						enabled: true,
						alpha: 45
					}
				},
				title: 0,
				yAxis: {
					showEmpty: false,
				},
				xAxis: {
					categories: categories,
				},
				plotOptions: {
					series: {
						colorByPoint: true
					},
					column: {
						pointPadding: -0.1,
						borderWidth: 0,
						showInLegend: false,
						depth: 45
					},
					pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						showInLegend: true,
						depth: 45,
						innerSize: 70
					}
				},
				legend: {
					enabled: legend
				},
				series: [{
					type: type,
					name: 'Jumlah Populasi',
					shadow: 1,
					border: 1,
					data: data
				}]
			});
		} else {
			chart_penduduk = new Highcharts.Chart({
				chart: {
					renderTo: 'container'
				},
				title: 0,
				yAxis: {
					showEmpty: false,
				},
				xAxis: {
					categories: categories,
				},
				plotOptions: {
					series: {
						colorByPoint: true
					},
					column: {
						pointPadding: -0.1,
						borderWidth: 0,
						showInLegend: false,
					},
					pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						showInLegend: true,
					}
				},
				legend: {
					enabled: legend
				},
				series: [{
					type: type,
					name: 'Jumlah Populasi',
					shadow: 1,
					border: 1,
					data: data
				}]
			});
		}

		$('#showData').click(function () {
			$('tr.lebih').show();
			$('#showData').hide();
			tampilkan_nol(false);
		});

	});
</script>
<!-- TODO: Pindahkan ke external css -->
<style>
	tr.lebih {
		display: none;
	}
	
	.input-sm
	{
		padding: 4px 4px;
	}
	@media (max-width:780px)
	{
		.btn-group-vertical
		{
			display: block;
		}
	}
	.table-responsive
	{
		min-height:275px;
	}
	}
</style>

<div class="box-default bgwhite mb-10">
	<div class="heading-module bggradient1 flexcenter">
	<i class="fa fa-bar-chart"></i><h1 class="flexcenter">Data Statistik</h1>
	</div>
	
	<div class="p-15">
	<div class="gridview">
		<div class="relative-hidden stat-isi">
			<div class="flexcenter stat-title mb-15">
			<h1>Data Demografi Berdasar <?=$heading?></h1>
			</div>
			<div class="flexcenter mb-15">
				<a class="btn mlr-3 <?= ($tipe==0) ? 'bgcolor2' : 'bgcolor2' ?> btn-xs" onclick="switchType();">Pie Cart</a>
				<a class="btn mlr-3 <?= ($tipe==1) ? 'bgcolor1' : 'bgcolor1' ?> btn-xs" onclick="switchType();">Bar Graph</a>
				
			</div>
			<div id="container"></div>
			<div id="contentpane">
				<div class="ui-layout-north panel top"></div>
			</div>
			<div class="width-default mt-20">
				<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th rowspan="2">Kode</th>
							<th rowspan="2" style='text-align:left;'>Kelompok</th>
							<th colspan="2">Jumlah</th>
							<?php if ($jenis_laporan == 'penduduk'):?>
								<th colspan="2">Laki-laki</th>
								<th colspan="2">Perempuan</th>
							<?php endif;?>
						</tr>
						<tr>
							<th style='text-align:right'>n</th><th style='text-align:right'>%</th>
							<?php if ($jenis_laporan == 'penduduk'):?>
								<th style='text-align:right'>n</th><th style='text-align:right'>%</th>
								<th style='text-align:right'>n</th><th style='text-align:right'>%</th>
							<?php endif;?>
						</tr>
					</thead>
					<tbody>
						<?php $i=0; $l=0; $p=0; $hide=""; $h=0; $jm1=1; $jm = count($stat); ?>
						<?php foreach ($stat as $data):?>
							<?php $jm1++; if (1):?>
								<?php $h++; if ($h > 12 AND $jm > 10): $hide="lebih"; ?>
								<?php endif;?>
								<tr class="<?=$hide?>">
									<td class="angka">
										<?php if ($jm1 > $jm - 2):?>
											<?=$data['no']?>
										<?php else:?>
											<?=$h?>
										<?php endif;?>
									</td>
									<td><?=$data['nama']?></td>
									<td class="angka <?php ($jm1 <= $jm - 2) and ($data['jumlah'] == 0) and print('nol')?>"><?=$data['jumlah']?></td>
									<td class="angka"><?=$data['persen']?></td>
									<?php if ($jenis_laporan == 'penduduk'):?>
										<td class="angka"><?=$data['laki']?></td>
										<td class="angka"><?=$data['persen1']?></td>
										<td class="angka"><?=$data['perempuan']?></td>
										<td class="angka"><?=$data['persen2']?></td>
									<?php endif;?>
								</tr>
								<?php $i += $data['jumlah'];?>
								<?php $l += $data['laki']; $p += $data['perempuan'];?>
							<?php endif;?>
						<?php endforeach;?>
					</tbody>
				</table>
				<div class="flexcenter mt-20">
				<?php if($hide=="lebih"):?>
					<button style='margin:0 5px' class='tombol-default bg-style3 borderradius-5 flexcenter' id='showData'>Selengkapnya...</button>
				<?php endif;?>
					<button style='margin:0 5px' id='tampilkan' onclick="toggle_tampilkan();" class="tombol-default bg-style3 borderradius-5 flexcenter">Tampilkan Nol</button>
				</div>
			</div>
			</div>
			<?php if ($this->setting->daftar_penerima_bantuan):?>
			<?php if (in_array($st, array('bantuan_keluarga', 'bantuan_penduduk'))):?>
			<div class="width-default mt-30">
				<input id="stat" type="hidden" value="<?=$st?>">
				<div class="head-center-inner flexcenter mb-10 color-1">
					<h1 class="border-3">Daftar <?= $heading ?></h1>
				</div>
				<div class="table-responsive">
					<table class="table table-striped table-bordered" id="peserta_program">
						<thead>
							<tr>
								<th>No</th>
								<th>Program</th>
								<th>Nama Peserta</th>
								<th>Alamat</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
			<script type="text/javascript">
				$(document).ready(function() {

					var url = "<?= site_url('first/ajax_peserta_program_bantuan')?>";
					table = $('#peserta_program').DataTable({
						'processing': true,
						'serverSide': true,
						"pageLength": 10,
						'order': [],
						"ajax": {
							"url": url,
							"type": "POST",
							"data": {stat: $('#stat').val()}
						},
						//Set column definition initialisation properties.
						"columnDefs": [
							{
								"targets": [ 0, 3 ], //first column / numbering column
								"orderable": false, //set not orderable
							},
						],
						'language': {
							'url': BASE_URL + '/assets/bootstrap/js/dataTables.indonesian.lang'
						},
						'drawCallback': function (){
							$('.dataTables_paginate > .pagination').addClass('pagination-sm no-margin');
						}
					});

				} );
				</script>
			<?php endif;?>
			<?php endif;?>
		</div>
		<div class="sidebarright">
			<img style="width:100%;height:1px;display:block;" src="<?= base_url("$this->theme_folder/$this->theme/images/bigblank-image.png") ?>"/>
			<ul>
				<?php $this->load->view($folder_themes .'/partials/statistik/statistik_nav') ?>
			</ul>
		</div>
	</div>
	</div>

</div>



