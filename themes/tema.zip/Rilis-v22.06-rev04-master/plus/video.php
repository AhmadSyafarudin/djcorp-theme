<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>


<div class="video">
	<div class="relative-hidden ptb-5">
	<a data-toggle="collapse" data-parent="#accordion" href="#collapsevideo">
		<div class="heading-module bggradient1 flexcenter">
		<i class="fa fa-video-camera"></i><h1 class="flexcenter">Video</h1>
		</div>
	</a>	
	<div id="collapsevideo" class="panel-collapse collapse">	
	<div class="box-default bgwhite" style="border-radius:0 0 5px 5px">
		<div class="relative-hidden pt-10 plr-5">
		<div class="flex-container">
		
			<!-- video -->
			<div class="flexitem-4-news">
				<div class="p-5">
				<div class="box-video backg-white">
					<iframe class="video-box" align="center" src="https://www.youtube.com/embed/8UF-xOxHsnU" frameborder="0"allowfullscreen></iframe>
				</div>
				<div class="video-title flexcenter pt-5"><p><b>Tujuan SDGS Desa1</b></p></div>
				</div>
			</div>
			<!-- batas video -->
			
			<!-- video -->
			<div class="flexitem-4-news">
				<div class="p-5">
				<div class="box-video backg-white">
					<iframe class="video-box" align="center" src="https://www.youtube.com/embed/8UF-xOxHsnU" frameborder="0"allowfullscreen></iframe>
				</div>
				<div class="video-title flexcenter pt-5"><p><b>Tujuan SDGS Desa1</b></p></div>
				</div>
			</div>
			<!-- batas video -->
			
			<!-- video -->
			<div class="flexitem-4-news">
				<div class="p-5">
				<div class="box-video backg-white">
					<iframe class="video-box" align="center" src="https://www.youtube.com/embed/8UF-xOxHsnU" frameborder="0"allowfullscreen></iframe>
				</div>
				<div class="video-title flexcenter pt-5"><p><b>Tujuan SDGS Desa1</b></p></div>
				</div>
			</div>
			<!-- batas video -->
			
			<!-- video -->
			<div class="flexitem-4-news">
				<div class="p-5">
				<div class="box-video backg-white">
					<iframe class="video-box" align="center" src="https://www.youtube.com/embed/8UF-xOxHsnU" frameborder="0"allowfullscreen></iframe>
				</div>
				<div class="video-title flexcenter pt-5"><p><b>Tujuan SDGS Desa1</b></p></div>
				</div>
			</div>
			<!-- batas video -->
			
		</div>
		</div>
	</div>
	</div>
	</div>
</div>	

