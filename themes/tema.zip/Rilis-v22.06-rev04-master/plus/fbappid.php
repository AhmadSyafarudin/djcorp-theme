<?php if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v3.2&appId=328618625940706&autoLogAppEvents=1"></script>