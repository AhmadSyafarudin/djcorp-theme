<?php if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>


<link rel="stylesheet" href="<?= base_url("$this->theme_folder/$this->theme/assets/css/mode/full.css"); ?>">

<!-- Ganti tampilan layar
   Untuk mengganti tampilan layar tema Batuah, ganti tulisan full.css dengan box.css
-->

<!-- Keterangan :
   full.css -> margin kiri kanan layar rapat ke pinggir 
   box.css -> margin kiri kanan layar berjarak dari pinggir
-->