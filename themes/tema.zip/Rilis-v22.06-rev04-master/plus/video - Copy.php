<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="video">
	<div class="relative-hidden ptb-5">
	<div class="box-default bgwhite">
		<div class="heading-module bggradient1 flexcenter">
		<i class="fa fa-video-camera"></i><h1 class="flexcenter">Video</h1>
		</div>
		<div class="relative-hidden p-10 mlr-min-5">
			<div class="carouselright js-flickity" data-flickity='{ "autoPlay": false, "cellAlign": "left", "wrapAround": true }'>
				<!-- video -->
				<div class="carouselright-cell">
					<div class="plr-5">
						<div class="box-video backg-white">
							<iframe class="video-box" align="center" src="https://www.youtube.com/embed/8UF-xOxHsnU" frameborder="0"allowfullscreen></iframe>
						</div>
						<div class="video-title flexcenter pt-5"><p><b>Tujuan SDGS Desa1</b></p></div>
					</div>
				</div>
				<!-- batas video -->
				<!-- video -->
				<div class="carouselright-cell">
					<div class="plr-5">
						<div class="box-video backg-white">
							<iframe class="video-box" align="center" src="https://www.youtube.com/embed/8UF-xOxHsnU" frameborder="0"allowfullscreen></iframe>
						</div>
						<div class="video-title flexcenter pt-5"><p><b>Tujuan SDGS Desa1</b></p></div>
					</div>
				</div>
				<!-- batas video -->
				<!-- video -->
				<div class="carouselright-cell">
					<div class="plr-5">
						<div class="box-video backg-white">
							<iframe class="video-box" align="center" src="https://www.youtube.com/embed/8UF-xOxHsnU" frameborder="0"allowfullscreen></iframe>
						</div>
						<div class="video-title flexcenter pt-5"><p><b>Tujuan SDGS Desa1</b></p></div>
					</div>
				</div>
				<!-- batas video -->
				<!-- video -->
				<div class="carouselright-cell">
					<div class="plr-5">
						<div class="box-video backg-white">
							<iframe class="video-box" align="center" src="https://www.youtube.com/embed/8UF-xOxHsnU" frameborder="0"allowfullscreen></iframe>
						</div>
						<div class="video-title flexcenter pt-5"><p><b>Tujuan SDGS Desa1</b></p></div>
					</div>
				</div>
				<!-- batas video -->
			</div>
		</div>
	</div>
	</div>
</div>	

