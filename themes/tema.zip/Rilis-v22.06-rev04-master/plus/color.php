<?php if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<!-- ganti warna default -->

<link rel="stylesheet" href="<?= base_url("$this->theme_folder/$this->theme/assets/css/color/green.css"); ?>">

<!-- ganti warna default
untuk mengganti warna default tema Batuah, ganti tulisan hijau.css dengan salahsatu list di bawah :
biru.css
merah.css
ungu.css
abu.css
hijau.css
-->