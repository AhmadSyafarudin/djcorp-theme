<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="box-default bgwhite mb-10">
<div class="heading-module bggradient1 flexcenter">
	<i class="fa fa-folder"></i><h1 class="flexcenter"><?= $judul_widget ?></h1>
	</div>
<div class="relative-row p-10">
	<a href="https://play.google.com/store/apps/details?id=com.my.sidodibaru2022" target="blank">
	<img style="width:100%;height:auto;" src="<?= base_url("$this->theme_folder/$this->theme/images/playstore.png") ?>"/>
	</a>
</div>
</div>




