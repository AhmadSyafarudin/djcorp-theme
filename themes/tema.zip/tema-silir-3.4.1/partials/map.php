<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<section class="map">
  <?php $this->load->view($halaman_peta); ?>
</section>