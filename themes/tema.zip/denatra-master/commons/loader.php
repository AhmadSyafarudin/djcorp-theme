<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<!--
<?php if (in_array($this->uri->segment(1), ['', 'first']) && (in_array($this->uri->segment(2), ['']))): ?>
<div class="loader preloader align-items-center justify-content-center">
	<div class="preloader-inner position-relative">
      	<div class="preloader-circle"></div>
		<div class="preloader-img pere-text">
			<img src="<?= gambar_desa($desa['logo']);?>" alt="">
		</div>
	</div>
</div>
<?php endif; ?>
-->
